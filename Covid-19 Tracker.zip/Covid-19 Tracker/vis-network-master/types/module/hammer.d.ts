import hammer from '@egjs/hammerjs'
export = hammer

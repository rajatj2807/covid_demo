declare const whoKnowsWhat: any
export default whoKnowsWhat
